"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/builtin/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "default", {
  enumerable: true,
  get: function get() {
    return _BottomNavigationAction.default;
  }
});

var _BottomNavigationAction = _interopRequireDefault(require("./BottomNavigationAction"));