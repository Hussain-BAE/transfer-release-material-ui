export { default } from './Slide';
export * from './Slide';
